# Cache
* Path : `main_startup/Cache`
* Whats In Here? : `None, But All chache Files Will Be Stored Here!`
