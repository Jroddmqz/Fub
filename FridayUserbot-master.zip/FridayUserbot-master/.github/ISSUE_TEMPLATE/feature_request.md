---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE-REQUEST]"
labels: enhancement
assignees: ''

---

<!-- WARNING: Ignoring this template could lead to the issue being closed as invalid -->

## Checklist
- [ ] I Confirm this is awesome and would benefit the Software.
- [ ] I Confirm That This is Not A Duplicate Feature Request

## Description
A detailed description of the Feature.
