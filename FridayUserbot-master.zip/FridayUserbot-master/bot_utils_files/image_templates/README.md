# Image Templates

* Path : `bot_utils_files/image_templates`
* Whats In Here? : `Contains All Many Image Templetes For Some Plugins!`
* Note : `We Are Not CopyRight Holders Of These Images, These Are Mostly Taken From Google.com!`
