# Fonts
* Path : `bot_utils_files/Fonts`
* Whats In Here? : `Contains All Types Of Fonts For Some Modules To Work!`
* Note : `We Are Not CopyRight Holders Of Fonts The That You Can Find Here, All Fonts Are Taken From DaFont.com!`
